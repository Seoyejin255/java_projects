package com.yejin.health_care;

import java.util.ArrayList;
import java.util.Scanner;

public class Member {

	
	private String name;
	private String tel;
	private String sex;
	Command cmd= new Command();
	
	public void memeber(String name, String tel, String sex) {
		this.name=name;
		this.tel=tel;
		this.sex=sex;
	}

	public void input_info() {
			this.name =cmd.getCommand("회원님의 이름을 입력해주세요.");
			this.tel =cmd.getCommand("회원님의 폰 번호를 입력해주세요.");
			this.sex =cmd.getCommand("회원님의 성별(남/여)를 입력해주세요.");
	}
	
	public void mem_info() {
		String s=String.format("\n-------------------------------------------------------------\n[%s회원님의 정보]\n핸드폰 번호 : %s\n성별 : %s\n", this.name,this.tel,this.sex);
		System.out.println(s);
	}
	
	public String getName() {
		return name;
	}

	public String getTel() {
		return tel;
	}

	public String getSex() {
		return sex;
	}

	public void setName(String name) {
		this.name=name;
	}
	public void setTel(String tel) {
		this.tel=tel;
	}
	public void setSex(String sex) {
		this.sex=sex;
	}
	

}
