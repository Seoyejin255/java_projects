package com.yejin;

import java.util.ArrayList;

import com.yejin.health_care.Command;
import com.yejin.health_care.Member;
import com.yejin.health_care.display.Title;

public class main2 {
	
	public static void main(String[] args) {
		boolean wh_flag=true;
		String if_flag;
		Command cmd = new Command();
		System.out.println(Title.TITLE);

		ArrayList<Member> members = new ArrayList<Member>();
		Member mem1 = new Member();
		Member mem2 = new Member();
		
		mem1.input_info();
		mem2.input_info();
		
		members.add(mem1);
		members.add(mem2);
		

		while(wh_flag) {
			if_flag=cmd.getCommand("회원정보 출력을 원한다면 '출력'을, 회원 삭제를 원한다면 '삭제'를\n"
					+ "프로그램 종료를 원한다면 '종료'를, 회원 수정을 원한다면 '수정'을 입력해주세요.");
			if(if_flag.equals("출력")) {
				for(int i=0;i<members.size();i++) {
					members.get(i).mem_info();
				}
			}else if(if_flag.equals("종료")) {
				wh_flag=false;
			}else if(if_flag.equals("삭제")) {
				String delete=cmd.getCommand("어떤 멤버를 삭제할지 '이름'을 입력해주십시오.");
				for(int i=0;i<members.size();i++) {
					String name=members.get(i).getName();
					if(name.equals(delete)) members.remove(i);
				}
			}else if(if_flag.equals("수정")) {
				String edit=cmd.getCommand("어떤 멤버를 삭제할지 '이름'을 입력해주십시오.");
				for(int i=0;i<members.size();i++) {
					String name=members.get(i).getName();
					if(name.equals(edit)) {
						String name_e=cmd.getCommand("수정할 이름은?");
						members.get(i).setName(name_e);
						String tel_e=cmd.getCommand("수정할 폰번호는?");
						members.get(i).setTel(tel_e);
						String sex_e=cmd.getCommand("수정할 성별은?");
						members.get(i).setSex(sex_e);
					}
				}
			}
			else {
				System.out.println("오타가 난거 같아요. 다시 입력해주세요.\n");
			}
		}
		System.out.println("-----------------------프로그램을 종료합니다------------------------");
		
		
		
		//members.get(1).mem_info();
	}
}
