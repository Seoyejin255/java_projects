package com.yejin;

import java.util.ArrayList;

import com.yejin.health_care.Command;
import com.yejin.health_care.Member;
import com.yejin.health_care.display.Title;

public class main {
	
	public static void main(String[] args) {
		boolean wh_flag=true;
		String if_flag;
		Command cmd = new Command();
		
		Title.showTitle();

		ArrayList<Member> members = new ArrayList<Member>();
		int input_num=Integer.parseInt(cmd.getCommand("몇명의 회원을 등록할건가요?"));
		System.out.println(input_num);
		
		for(int i=0;i<input_num;i++) {
			members.add(new Member());
			members.get(i).input_info();
		}

		while(wh_flag) {
			if_flag=cmd.getCommand("회원정보 출력을 원한다면 '출력'을, 회원 삭제를 원한다면 '삭제'를\n"
					+ "프로그램 종료를 원한다면 '종료'를, 회원 수정을 원한다면 '수정'을 입력해주세요.");
			if(if_flag.equals("출력")) {
				Title.showinfo();
				for(int i=0;i<members.size();i++) {
					members.get(i).mem_info();
				}
			}else if(if_flag.equals("종료")) {
				wh_flag=false;
			}else if(if_flag.equals("삭제")) {
				int count=0;
				Title.showdelete();
				String delete=cmd.getCommand("어떤 멤버를 삭제할지 '이름'을 입력해주십시오.");
				for(int i=0;i<members.size();i++) {
					String name=members.get(i).getName();
					if(name.equals(delete)) {
						members.remove(i);
						count++;
					}
				}
				if(count==0)Title.noMember();
			}else if(if_flag.equals("수정")) {
				Title.showEdit();
				String edit=cmd.getCommand("어떤 멤버를 수정할지 '이름'을 입력해주십시오.");
				for(int i=0;i<members.size();i++) {
					String name=members.get(i).getName();
					if(name.equals(edit)) {
						String name_e=cmd.getCommand("수정할 이름은?");
						members.get(i).setName(name_e);
						String tel_e=cmd.getCommand("수정할 폰번호는?");
						members.get(i).setTel(tel_e);
						String sex_e=cmd.getCommand("수정할 성별은?");
						members.get(i).setSex(sex_e);
					}
				}
			}
			else {
				Title.showError();
			}
		}
		Title.showExit();
		
	}
}
