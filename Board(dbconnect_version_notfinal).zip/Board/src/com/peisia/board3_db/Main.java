package com.peisia.board3_db;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		procBoard pB = new procBoard();
		int count=0;
		
		loop:
		while(true) {
			System.out.println("명령을 입력해주세요. [1:글추가, 2:글리스트, 3:글보기, 4:글 삭제, 5:글 수정, 6:공감, 7:인기글, 8:댓글, e:프로그램 종료 ]");
			String a=sc.next();

			switch(a) {
			case "1":
				System.out.println("================글 추가================");
				System.out.println("아이디");
				String id =sc.next();
				System.out.println("글 제목");
				String title =sc.next();
				System.out.println("글 내용");
				String content =sc.next();
				pB.db_update(id,title,content);
				break;
				
			case "2":
				System.out.println("================글 리스트================");
				pB.db_list();
				break;
				
//			case "3":
//				System.out.println("================글 보기=================");
//				System.out.println("보고싶은 글의 번호를 입력하세요.");
//				int num=sc.nextInt();
//				for(int i=0;i<post.size();i++) {
//					if(num==post.get(i).no) {
//						System.out.println("\n================================");
//						System.out.println("아이디 : "+post.get(i).id);
//						System.out.println("제목 : "+post.get(i).title);
//						System.out.println("내용 : "+post.get(i).content);
//						System.out.println("시간 : "+post.get(i).now);
//						System.out.println("===================================");
//						System.out.println("\t 공감["+post.get(i).like+"]\n");
//						System.out.println("==================================");
//						System.out.println("댓글");
//						System.out.println("=================================");
//						for(int b=0;b<comment.size();b++) {
//							if(comment.get(b).num==num) {
//								System.out.println("닉네임 : "+comment.get(b).nickname);
//								System.out.println(comment.get(b).comment);
//								System.out.println("------------------------------------");
//							}
//						}
//					}
//				}
//				break;
				
			case "4":
				System.out.println("================글 삭제================");
				System.out.println("삭제하고싶은 글의 번호를 입력하세요.");
				String delNo=sc.next();
				pB.db_delete(delNo);
				break;
				
			case "5":
				System.out.println("================글 수정================");
				System.out.println("수정하고싶은 글의 번호를 입력하세요.");
				System.out.println("수정하고싶은 것은?[제목/내용/아이디]");
				String str = sc.next();
				if(str.equals("제목")) {
					
				}else if(str.equals("내용")) {
					
				}else if(str.equals("아이디")) {
					
				}
				break;
//			case "6":
//				System.out.print("공감하고싶은 글의 번호 : ");
//				int strLike=sc.nextInt();
//				for(int i=0;i<post.size();i++) {
//					if(strLike==(post.get(i).no)) {
//						post.get(strLike).like+=1;
//					}
//				}
//				break;
//				
//			case "7":
//				System.out.println("================인기글================");
//				int poCount=0;
//				for(int i=0;i<post.size();i++) {
//					if(post.get(i).like>=2) {
//						String s = String.format("%s %s %s %d [공감 : %d]", post.get(i).id,post.get(i).title,post.get(i).content,post.get(i).no,post.get(i).like);
//						System.out.println(s);
//						poCount++;
//					}
//				}
//				if(poCount==0)System.out.println("없음\n");
//				break;
//			case "8":
//				System.out.println("================댓글 달기=================");
//				System.out.println("댓글 달고싶은 글의 번호를 입력하세요.");
//				int comNum=sc.nextInt();
//				System.out.println("유저이름");
//				String comName=sc.next();
//				System.out.println("내용");
//				String comCont=sc.next();
//				comment.add(new Comment(comName,comCont,comNum));
//				for(int i=0;i<(post.size());i++) {
//					if(comNum==(post.get(i).no)) {
//						post.get(i).count+=1;
//					}
//				}
//				break;
//				
			case "e":
				System.out.println("프로그램이 종료되었습니다.");
				break loop;
			}
		}
		
	}

}
