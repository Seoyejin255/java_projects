package matjib_list.food;

public class Food {
	String food_info;
	int food_value;
	String food_location;

	public Food(String food_info, int food_value, String food_location) {
		this.food_info = food_info;
		this.food_value = food_value;
		this.food_location = food_location;
	}
	//가격,위치
	public void food_eidt(String menu,String str) {
		if(menu.equals("정보")) {
			this.food_info=str;
		}else if(menu.equals("가격")) {
			this.food_value=Integer.parseInt(str);
		}else if(menu.equals("위치")) {
			this.food_location=str;
		}
	}
	
	
}
