package matjib_list.board;

public class Write {
	public String nickname;
	public String id;
	public String title;
	public String content;

	public Write(String nickname, String id, String title, String content) {
		this.nickname = nickname;
		this.id = id;
		this.title = title;
		this.content = content;
	}
	
	
}
