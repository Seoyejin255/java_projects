package matjib_list.parentclass;

public class Goyang extends Area{

}
