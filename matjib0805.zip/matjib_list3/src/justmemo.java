
public class justmemo {
//	case "관리자" :
//	boolean flag=true;
//	boolean se_flag=true;
//	while(flag) {
//		String maFlag="true";//이건 수정해야함.
//		if(maFlag.equals("true")) {
//			while(se_flag) {
//				String maSelect=Command.getCommand("[관리자]기능을 선택해주세요. >> (1)리스트수정  (2)리스트추가 (3)exit");
//				if(maSelect.equals("1")) {
//					String fType=Command.getCommand("어떤 종류의 음식점을 수정하시겠습니까?[한식/카페/양식]");
//					if(fType.equals("한식")||fType.equals("카페")||fType.equals("양식")) {
//						String fName=Command.getCommand("수정할 가게의 이름은?");
//						((Goyang_Food)area_go).editFood(fType,fName);
//					}else {
//						System.out.println("다시 입력해주세요.");
//					}
//					
//				}else if(maSelect.equals("2")) {
//					((Goyang_Food)area_go).foodAdd();
//					
//				}else if(maSelect.equals("3")) {
//					se_flag=false;
//					flag=false;
//				}
//			}
//			
//		}else if(maFlag.equals("false")) {
//			String relog=Command.getCommand("로그인을 실패했어요. 다시 로그인하실래요?[yes/no]");
//			if(relog.equals("yes")) {
//			}else{
//				flag=false;
//			}
//		}
//	}
//	break;
}
