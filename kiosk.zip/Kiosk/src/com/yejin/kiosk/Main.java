package com.yejin.kiosk;

import java.util.ArrayList;

import com.yejin.kiosk.close.Close;
import com.yejin.kiosk.open.Open;
import com.yejin.kiosk.system.Command;
import com.yejin.kiosk.system.Title;
import com.yejin.kiosk.table.Table;

public class Main {
	
	public static void main(String[] args) {
		Open open = new Open();
		Close close = new Close();
		
		while(true) {//무한루프
			boolean button1 = false;//전원 끌지 안끌지 변수
			//기능 선택, 마감에서 변수를 false로 바꾸면 됨
			String function_m;//메인메뉴 기능 선택 변수
			
			//5개의 table을 담을수있는 어레이 리스트를 배정함.
			button1=Command.Turn_On();//전원켤지 입력받음.
			while(button1) {//전원켜고나서 실행해야할것들.
				//두번쨰 while문에서 초기화 할 변수 및 배열들
				
				ArrayList<Table> table = new ArrayList<>();//테이블 객체를 담을 변수
				int hyeongeum = 0;
				int totalpay=0;
				
				for(int i=0;i<10;i++) {
					table.add(new Table(0,0));
				}
				
				int open_money=open.today_money();//오늘의 오픈 금액
				boolean button2 = true;
				
				while(button2) {//기능선택을 반복하는 함수
					int i;
					function_m=Command.getCommand(Title.function_m);//기능선택
					if(function_m.equals("테이블")) {//테이블을 눌렀을때
						i= Integer.parseInt(Command.table_select());//테이블 번호 지정
						String select_main=table.get(i).Select_main();// 테이블 기능 지정
						//[테이블] ->[음식 or 계산]
						if(select_main.equals("음식")) {
							table.get(i).food_info();
							table.get(i).Select_food();
						}else if(select_main.equals("계산")){
							table.get(i).Select_pay();
							int value=table.get(i).food_sum;
							table.get(i).order_info(value,i);//계산 총 결제 금액 출력
							hyeongeum+=table.get(i).hyeongeum;
							totalpay+=table.get(i).food_sum;
							table.get(i).food_sum=0;
							table.get(i).hyeongeum=0;
						}else System.out.println("다시 입력해주세요.");
					}//첫 if문 끝 => [테이블] 기능
					else if(function_m.equals("테이블이동")) {//[테이블 이동] 기능
						int from = Integer.parseInt(Command.getCommand("테이블 선택"));
						int to = Integer.parseInt(Command.getCommand("옮길 테이블"));
						int from_money=table.get(from).food_sum;
						table.get(to).food_sum=from_money;
						table.get(from).food_sum=0;
						//모든 값들을 다른테이블에 옮겨놓고, 
					}else if(function_m.equals("마감")) {//[마감] 기능
						open_money+=hyeongeum;
						close.close_info(totalpay, hyeongeum, open_money);//총결제액,현금결제액,금고총액 나오는 함수
						button2=Command.Turn_Off();//여기도 마감에 넣을거임
					}
				}//button2 마무리
			}//전원키고나서 할 while문 종료
			
		}//무한 while문 
	}

	
	
}
