package com.yejin.kiosk.system;

public class Title {

	public static String OPEN="----------------------오픈 : [YES / NO]-----------------------";
	public static String CLOSE="----------------------마감 : [YES / NO]-----------------------";
	public static String function_m="---------------기능 : [테이블 / 테이블이동 / 마감]------------";
	public static String LINE="=============================================================";


}
