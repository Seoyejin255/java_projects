package com.yejin.kiosk.money;

public class Money {
	
}
