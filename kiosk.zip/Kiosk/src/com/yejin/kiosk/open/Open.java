package com.yejin.kiosk.open;

import com.yejin.kiosk.system.Command;

public class Open {
	public int today_money;
	
	public int today_money() {
		String str = Command.getCommand("오늘의 시작 금액은 얼마인가요?");
		int money = Integer.parseInt(str); 
		this.today_money=money;
		String money_info=String.format("현재 금고 : %d\n",today_money);
		System.out.println(money_info);
		return money;
	}
	
}
