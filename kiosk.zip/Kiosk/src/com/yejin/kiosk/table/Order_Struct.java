package com.yejin.kiosk.table;

import com.yejin.kiosk.system.Command;

public interface Order_Struct {
	int burger=5000,spagetti=8000,pizza=15000;//메인메뉴
	int cookie=1500,cheeseball=5000;
	int cider=4000,coke=4000,soju=4000;
	
	public default void method1() {
		System.out.println("1");
	}
	
	public default int food_type() {//음식 선택하는 함수
		int value=0;
			loop:
			while(true) {
			String food_type=Command.getCommand("음식 선택(뒤로가기 : exit)");
			
			switch(food_type) {
				case "burger":
					int food_count=Integer.parseInt(Command.getCommand("개수 선택"));
					value += burger*food_count;
					break;
				case "spagetti":
					food_count=Integer.parseInt(Command.getCommand("개수 선택"));
					value += spagetti*food_count;
					break;
				case "pizza":
					food_count=Integer.parseInt(Command.getCommand("개수 선택"));
					value += pizza*food_count;
					break;
				case "cheeseball":
					food_count=Integer.parseInt(Command.getCommand("개수 선택"));
					value += cheeseball*food_count;
					break;
				case "cookie":
					food_count=Integer.parseInt(Command.getCommand("개수 선택"));
					value += cookie*food_count;
					break;
				case "cider":case "coke":case"soju":
					food_count=Integer.parseInt(Command.getCommand("개수 선택"));
					value += cider*food_count;
					break;
				case "exit":
					break loop;
			}
			
		}
		return value;
		
	}
	public default void food_info() {// 음식정보 함수
		System.out.println("========================메뉴판========================");
		String main=String.format("[메인]\nburger:%d spagetti:%d pizza:%d",burger,spagetti,pizza);
		System.out.println(main);
		String side=String.format("[사이드]\ncookie:%d cheeseball:%d ",cookie,cheeseball);
		System.out.println(side);
		String drink=String.format("[음료]\ncider:%d coke:%d soju:%d",cider,coke,soju);
		System.out.println(drink);
		System.out.println("====================================================");
	}
	
	public default void order_receipt() {//영수증 출력하는 함수.
		
	}
}
