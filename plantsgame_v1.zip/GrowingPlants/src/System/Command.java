package System;

import java.util.Scanner;

public class Command {
	public static String TITLE="ꕤꕥ ꕤꕥ ꕤꕥ 꽃 키우기 ꕤꕥ ꕤꕥ ꕤꕥ";
	public static String TWOLINE="===============================";
	
	public static String getCommand(String str){
		Scanner sc = new Scanner(System.in);
		System.out.println(str);
		String cmd = sc.next();
		return cmd;
	}
	

	
	
}
