package Main;

import java.sql.SQLException;
import java.util.ArrayList;

import DBs.DB;
import DBs.LoginProcess;
import System.Command;

public class Main {
	 
	public static void main(String[] args) throws SQLException {
		DB db = new DB();
		LoginProcess lp = new LoginProcess();
		System.out.println(Command.TITLE+"\n");
		String nowUser=lp.userLog();//현재 로그인된 유저 나옴.
		while(true) {
			Game game = new Game();
			if(nowUser!=null) {
				game.play(nowUser);//게임 시작	
			}	
		}
		
		

		}
	}