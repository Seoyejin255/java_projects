package Main;

import java.sql.SQLException;

import Objects.Flower;
import System.Command;

public class Game {
	public void play(String user) throws SQLException {
		Flower flower = new Flower();
		System.out.println(Command.TWOLINE);
		String a=Command.getCommand("✿❀ ▷[1] 나의 꽃 [2] 꽃 상태 ◁ ❀✿");
		System.out.println(Command.TWOLINE);
		switch(a) {
		case "1":
			flower.findFlower(user);
			break;
		}
	}
}
