package Objects;

import java.sql.ResultSet;
import java.sql.SQLException;

import DBs.DB;
import System.Command;

public class Flower {
	
	public static void findFlower(String user) throws SQLException {
		DB db = new DB();
		db.dbInit();
		String flower=db.dbExecuteQuery("select * from user where unickname='"+user+"'", "꽃");
		if(flower==null) {
			
			String str =Command.getCommand("꽃을 배정받지 않았습니다. 새로 만들까요?-----[yes / no]");
			if(str.equals("yes")) {
				getFlower(user);
			}else {
				System.out.println("꽃을 배정받지 않았습니다.");
			}
		}else if(flower!=null) {
			System.out.println("당신의 꽃은 <"+flower+"> 입니다.");
		}
	}
	
	public static void getFlower(String user) throws SQLException {
		//select count(*) from flower;
		DB db = new DB();
		db.dbInit();
		int num=db.fCount("select * from flower");
		int rannum=(int) (Math.random()*num+1);
		String flower =db.fExecuteQuery("select * from flower where num='"+rannum+"'", "꽃");
		db.dbExecuteUpdate("update user set uflower='"+flower+"' where unickname='"+user+"'");
	}
	
}
