package DBs;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class DB {
	Connection conn = null;
	Statement st = null;
	ResultSet rs = null;
	
	
	public void dbInit() throws SQLException{
		conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/plantgame","root","admin");
		st = conn.createStatement();
	}
	
	public String dbExecuteQuery(String query,String want) throws SQLException {
		rs = st.executeQuery(query);
		String a=null;
		while(rs.next()) {
			String nickname = rs.getString("unickname");
			String info = rs.getString("uinfo");
			String flower = rs.getString("uflower");
			if(want.equals("닉네임")) {
				a=nickname;
			}else if(want.equals("꽃")) {
				a=flower;
			}
		}
			return a;
	}
	public String fExecuteQuery(String query,String want) throws SQLException {
		rs = st.executeQuery(query);
		String a=null;
		while(rs.next()) {
			String num = rs.getString("num");
			String name = rs.getString("fname");
			String info = rs.getString("feature");
			int growPoint = rs.getInt("growPoint");
			if(want.equals("개수")) {
				a=Integer.toString(rs.getRow());
			}else if(want.equals("꽃")) {
				a=name;
			}
		}
			return a;
	}
	public void dbExecuteUpdate(String query) throws SQLException {
		st.executeUpdate(query);
	}
	
	public int fCount(String query) throws SQLException {
		rs =st.executeQuery(query);
		int rowcount =0;
		while(rs.next()) {
			rowcount++;
		}
		return rowcount;
	}
}
