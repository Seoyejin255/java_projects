package Objects;

import java.sql.SQLException;
import java.util.ArrayList;

import DBs.DB;
import System.Command;

public class Collection {
	//일단 USER가 가진 컬렉션들을 뽑아옴.
	static DB db = new DB();
	String collection[];
	Command command = new Command();
	public void UserCollection(String user) throws SQLException {//유저의 컬렉션을 나열해주는 함수.
		db.dbInit();
		String collect=db.dbExecuteQuery("select * from user where unickname='"+user+"'", "콜렉션");
		if(collect !=null) {
			collection = collect.split(",");
			for(int i=0;i<collection.length;i++) {
				System.out.println("ꕥ "+collection[i]+" ꕥ");
			}	
		}else if(collect==null) {
			System.out.println("▶ 컬렉션이 비어있습니다.");
		}
	}
	public void CollPaging(String user) throws SQLException {
		UserCollection(user);
		db.dbInit();
		String str =" ";
		int allCount=db.fCount("select * from flower")-3;
		
		if(collection==null) {
			for(int i=0;i<allCount;i++) {
				command.MysteryInfo();
			}
		}
		else if(collection !=null) {
			allCount=allCount-collection.length;
			for(int i=0;i<allCount;i++) {
				command.MysteryInfo();
			}
			for(int i=0;i<collection.length-1;i++) {
				 str+= ("fname='"+collection[i]+"' or ");
			}
			str+="fname='"+collection[collection.length-1]+"'";
			db.fExecuteQuery(("select * from flower where"+ str+";"),"유저꽃");
		}
	}
		
	public static void CollSearch() throws SQLException {
		db.dbInit();
	}
}
