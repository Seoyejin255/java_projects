package Main;

import java.sql.SQLException;
import java.util.ArrayList;

import DBs.DB;
import DBs.LoginProcess;
import System.Command;

public class Main {
	 /*
	  * 현재 식물 랜덤으로 부여하기 완료함.
	  * 
	  * 
	  * */
	public static void main(String[] args) throws SQLException {
		DB db = new DB();
		LoginProcess lp = new LoginProcess();
		System.out.println(Command.TITLE+"\n");
		while(true) {
			String nowUser=lp.userLog();//현재 로그인된 유저 나옴.
			boolean flag=true;
			while(flag) {
				Game game = new Game();
				if(nowUser!=null) {
					flag=game.play(nowUser);//게임 시작	
				}else if(nowUser==null) {
					flag=false;
				}
			}
		}
		}
	}