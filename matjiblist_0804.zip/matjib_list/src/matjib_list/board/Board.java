package matjib_list.board;

import matjib_list.command.Command;
import matjib_list.loginpro.Customer;

public class Board extends Customer{

	public String nickname;
	public String content;
	public String title;
	
	public Board(String nickname) {
		this.nickname = nickname;
	}

	public void create() {
		title = Command.getCommand("작성할 제목");
		content=Command.getCommand("작성할 내용");
	}
	
	public void showBoard() {
		Command.drawLine();
		System.out.println(title + "\t\t|" + nickname+"|");
		Command.drawLine();
		System.out.println(content);
	}
	public void showList() {
		
	}
	

}

