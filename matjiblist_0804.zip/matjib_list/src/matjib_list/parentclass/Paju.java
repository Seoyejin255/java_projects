package matjib_list.parentclass;

public class Paju extends Area{

	public Paju(String name) {
		this.name=name;
	}
}
