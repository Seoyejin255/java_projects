package matjib_list.loginpro;

import java.util.HashMap;
import java.util.Map;

import matjib_list.command.Command;

public class Manager{

	Map <String,User> manager = new HashMap<>();
	
	public void input_basic() {
		manager.put("manager", new User("1234","매니저1"));
	}
	
	public void newManager(String id,String pw, String nickname) {
		manager.put(id,new User(pw,nickname));
	}
	
	public String loginPro() {
		String reflag;
			String id=Command.getCommand("[관리자]아이디를 입력해주세요.");
			String pw=Command.getCommand("[관리자]비밀번호를 입력해주세요.");
			if(((manager.get(id)).pw).equals(pw)) {
				String nickname=(manager.get(id)).nickname;
				System.out.println("--------------------"+nickname+"님 안녕하세요 ^^--------------------");
				reflag="true";
			}else {
				System.out.println("[관리자]로그인 실패");
				reflag="false";
			}
			return reflag;
	}
	
	
	
}
