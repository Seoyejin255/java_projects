package matjib_list.loginpro;

import java.util.HashMap;
import java.util.Map;

public class Customer{
	Map<String,User> customer = new HashMap<>();
	
	public void inputMem() {
		customer.put("mem1", new User("1234","멍청이"));
	}
	
}
