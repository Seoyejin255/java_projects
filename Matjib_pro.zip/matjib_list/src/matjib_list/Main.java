package matjib_list;

import java.util.HashMap;
import java.util.Map;

public class Main {
	/*<<내일 할것들>>-아쉬운것들.
	 * Goyang_Food.java 中  공통된 코드를 하나의 메소드로 묶어서 코드 정리하기. 
	 * 음식점에 별점을 추가하는건 어떨까??
	 * 파주시 코드 추가?<<이건 근데 그냥 단순 노가다인데 너무 시간이 남으면 복습차원으로 해보기 ㄱㄱ
	 * 맛집을 추가 할 수 있는 기능
	 */
	public static void main(String[] args) {
		Area area = new Goyang_Food("고양시");
		((Goyang_Food)area).set_goyang();
		loop:
		while(true) {
			String select=Command.getCommand("지역을 선택해주세요. [고양시/파주시/추천/exit]");
			switch(select) {
			case "고양시":

				String goType=Command.getCommand("어떤 종류를 선택하시겠습니까?[한식/카페/양식]");
				if(goType.equals("한식")||goType.equals("카페")||goType.equals("양식")) {
					((Goyang_Food)area).info(goType);
					System.out.println();	
				}else {
					System.out.println("다시 입력해주세요.");
				}
				break;
			case "파주시":
				//단순 반복이니까 패스
				break;
				
			case "추천" :
				System.out.println("\n    제작자 :  < 오늘의 식당을 추천해줄게요 ^^)");
				((Goyang_Food)area).foodRandom();
				break;
				
			case "exit":
				break loop;
			
			}
		}
	}

}
