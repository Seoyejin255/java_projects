package matjib_list;

public class Area {
	public String name;
	public String type;
	
	
}
