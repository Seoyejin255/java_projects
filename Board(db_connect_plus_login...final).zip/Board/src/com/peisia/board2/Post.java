package com.peisia.board2;


public class Post{
	String title;//글제목
	String id;//아이디
	int no;//글번호
	String content;//글제목
	String now;//시간
	int like;//공감
	int count=0;//댓글카운트

	public Post(String id, String title,String content,int no,String now) {
		this.title = title;
		this.id = id;
		this.no = no;
		this.content = content;
		this.now=now;
	}
	 
}
