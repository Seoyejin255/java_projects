package com.peisia.board3_db_v2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ManagerLogin {
 
	Connection conn = null;
	Statement st = null;
	ResultSet rs =null;

	
	public void dbInit() throws SQLException {
		conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/kiosk","root","admin");
		st = conn.createStatement();
	}
	
	public String dbExecuteQuery(String query,String id, String pw) throws SQLException {
		int count=0;
		String flag = "false";
		dbInit();
		rs = st.executeQuery(query);
		while(rs.next()) {
			String mid = rs.getString("mid");
			String mpw = rs.getString("mpw");
			if(mid.equals(id)&&mpw.equals(pw)) {
				count++;
			}
		}
		if(count>0) {
			System.out.println("[매니저]로그인 성공하였습니다.");
			flag="true";
		}else if (count==0) {
			System.out.println("[매니저]로그인 실패하였습니다.");
			flag="false";
		}
		return flag;
	}

}
