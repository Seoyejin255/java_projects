package com.peisia.board3_db;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		procBoard pB = new procBoard();
		int count=0;
		
		loop:
		while(true) {
			System.out.println("명령을 입력해주세요. [1:글추가, 2:글리스트, 3:글보기, 4:글 삭제, 5:글 수정, 6:공감, 7:인기글, 8:댓글, e:프로그램 종료 ]");
			String a=sc.next();

			switch(a) {
			case "1":
				System.out.println("================글 추가================");
				System.out.println("아이디");
				String id =sc.next();
				System.out.println("글 제목");
				String title =sc.next();
				System.out.println("글 내용");
				String content =sc.next();
				pB.db_update(id,title,content);
				break;
				
			case "2":
				System.out.println("================글 리스트================");
				pB.db_list();
				break;
				
			case "3":
				System.out.println("================글 보기=================");
				System.out.println("보고싶은 글의 번호를 입력하세요.");String shownumber=sc.next();
				pB.show_writing(shownumber);
				break;
				
				
			case "4":
				System.out.println("================글 삭제================");
				System.out.println("삭제하고싶은 글의 번호를 입력하세요.");
				String delNo=sc.next();
				pB.db_delete(delNo);
				break;
				
			case "5":
				System.out.println("================글 수정================");
				System.out.println("수정하고싶은 글의 번호를 입력해주세요. ");String eid= sc.next();
				System.out.println("수정하고싶은 것은?[제목/내용]");String str = sc.next();
				System.out.println("수정할 내용을 입력하세요.");String edit = sc.next();
				pB.db_edit(str,edit,eid);
				break;
				
			case "6":
				System.out.print("공감하고싶은 글의 번호 : ");String num =sc.next();
				pB.db_like(num);
				break;
				
			case "7":
				System.out.println("================인기글================");
				pB.db_popular();
				break;
				
			case "8":
				System.out.println("================댓글 쓰기================");
				System.out.println("댓글 쓰고자 하는 글의 번호를 입력해주세요. ");String cnum= sc.next();
				System.out.println("닉네임을 입력해주세요.");String cid= sc.next();
				System.out.println("댓글을 입력해주세요. ");String comment= sc.next();
				pB.db_comment(cnum,cid,comment);
				break;
				
			case "e":
				System.out.println("프로그램이 종료되었습니다.");
				break loop;
			}
		}
	}
}
