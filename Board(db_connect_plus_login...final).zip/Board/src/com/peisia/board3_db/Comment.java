package com.peisia.board3_db;

public class Comment{

	String nickname;
	String comment;
	int num;

	public Comment(String nickname, String comment, int num) {
		this.nickname = nickname;
		this.comment = comment;
		this.num = num;
	}
	
	
	
}
