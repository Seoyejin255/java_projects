package com.peisia.board;

public class Post {
	String title; //글 제목
	String content; // 글 본문
	String id;
	int no;
	// alt+shift+s : 메뉴가 뜸
	
	public Post(String title, String content, String id, int no) {
		this.title = title;
		this.content = content;
		this.id = id;
		this.no = no;
	}
	
}
